VMS300 — 10 American country voice samples
==========================================

Synthetic American country-style voice auditions; regional accents vary.

HOW TO LISTEN
Download listening-page.html and open the saved file in Chrome, Edge, Firefox, or Safari.
All ten audio samples are embedded in that page; no internet connection is needed.
Use Play all in order, or the play control on an individual sample.
Each numbered MP3 can also be played on its own in your usual music player.
If you are viewing the files on GitHub, download the file before opening it.

HOW TO CHOOSE
Reply with your favourite sample number, or two numbers to blend.
Sample 10 is the custom voice blend used in the current video.

THE SHARED SAMPLE SCRIPT
Well howdy, y'all. Keep clear of that robot arm. Let's get this milking robot lined up proper. We'll leave the fancy talk out in the pasture. Tap Confirm once to check the gripper. If the position's right, press and hold Confirm to move on. Same buttons, new chores. Sounds like farm life.

VOICE INDEX
01. Adam — 01-adam.mp3
02. Echo — 02-echo.mp3
03. Eric — 03-eric.mp3
04. Fenrir — 04-fenrir.mp3
05. Liam — 05-liam.mp3
06. Michael — 06-michael.mp3
07. Onyx — 07-onyx.mp3
08. Puck — 08-puck.mp3
09. Santa — 09-santa.mp3
10. Current video blend — 10-current-video-blend.mp3

These short auditions help choose the narrator. Use the instructional video
for the full procedure and its safety requirements.
